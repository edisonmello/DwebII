<?php

	$aulas = array(

				'inicio' => array (
									'nome' => 'Início',
									'url'  => 'index.php' 
				),

				'variaveis' => array (
									'nome' => 'Variáveis e Constantes',
									'url'  => 'variaveis.php' 
				),

				'constantes' => array (
					'nome' => 'Constantes',
					'url'  => 'constantes.php' 
),

				'tipos-dados' => array (
									'nome' => 'Tipos de dados',
									'url'  => 'tipos-dados.php' 
				),

				'strings' => array (
									'nome' => 'Tipos de dados: Strings',
									'url'  => 'strings.php' 
				),

				'numeros' => array (
									'nome' => 'Tipos de dados: Números (Integer e Float)',
									'url'  => 'numeros.php' 
				),
				'array' => array (
					'nome' => 'Tipos de dados: array',
					'url'  => 'arrays.php' 
				)


	);

?>