<!DOCTYPE html>

<?php include 'functions/functions.php'; ?>

<html>

	<head>
		<title>Desenvolvimento Web 2</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css"></link>
		<link rel="stylesheet" type="text/css" href="css/gallery-001.css"></link>
		


	</head>
