<?php 
		include 'header.php';
		$aula_atual = 'inicio';
	?>


	<body>


		<h2>Índice de Aulas - Codificando na prática</h2>
		<hr>
		<small>Desenvolvimento Web II</small>
	





	<?php include 'functions/bottom_index.php'; ?>


	</body>

</html>