<?php 
		include 'header.php';
		$aula_atual = 'numeros';
	?>


	<body>

		<h2>NÚMEROS</h2>
		<hr>
		<small>Desenvolvimento Web II</small>

		<h3>Operadores Aritméticos</h3>

	
		<h3>Agora é a sua vez</h3>

			<p>Pesquise outros operadores aritméticos e funções matemáticas em PHP e use este espaço para testá-los.</p>
			<br>

	<?php include 'functions/bottom_index.php'; ?>


	</body>

</html>