<?php 
		include 'header.php';
		$aula_atual = 'strings';
	?>


	<body>

		<h2>STRINGS</h2>
		<hr>
		<small>Desenvolvimento Web II</small>

		<h3>Uma string é uma série de caracteres, onde um caractere é o mesmo que um byte</h3>
		
		
			
		<h3>Exemplo de Chassi - Trabalhando com Strings</h3>

		


		<h3>Como limpar strings</h3>

					

		

		<h3>Agora é a sua vez</h3>

			<p>Use este espaço para testar novas funções com strings.</p>
			<br>







	<?php include 'functions/bottom_index.php'; ?>


	</body>

</html>