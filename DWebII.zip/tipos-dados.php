<?php 
		include 'header.php';
		$aula_atual = 'tipos-dados';
	?>


	<body>

		<h2>Tipos de Dados</h2>
		<hr>
		<small>Desenvolvimento Web II</small>
		<br>
		<small>	Quatro tipos escalares:</small>
		<br>
			


		<h3>Função var_dump</h3>

	

	

		<?php include 'functions/bottom_index.php'; ?>


	</body>

</html>